//
//  MessageTableView.h
//  ASHMessageTableViewDemo
//
//  Created by xmfish on 15/1/19.
//  Copyright (c) 2015年 ash. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageTableView : UITableView

@end
