//
//  UIImage+StrethImage.h
//  气泡
//
//  Created by zzy on 14-5-13.
//  Copyright (c) 2014年 zzy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (StrethImage)

+(id)strethImageWith:(NSString *)imageName;
@end
